import React, { useEffect, useState } from 'react';
import { Pressable, StyleSheet, Text, View, Dimensions } from 'react-native';
import { VideoView, useVideoPlayer } from 'expo-video';

const { height: SCREEN_H } = Dimensions.get('window');

export type FeedVideo = {
  id: string;
  video_url: string;
  description: string;
  hashtags: string[];
  likes_count: number;
  comments_count: number;
  author: {
    id: string;
    username: string;
    avatar_url: string | null;
    verified: boolean;
  };
  liked?: boolean;
  saved?: boolean;
  following?: boolean;
};

type Props = {
  item: FeedVideo;
  active: boolean;
  onLike: () => void;
  onComment: () => void;
  onSave: () => void;
  onFollow: () => void;
};

export default function VideoCard({ item, active, onLike, onComment, onSave, onFollow }: Props) {
  const [paused, setPaused] = useState(false);
  const player = useVideoPlayer(item.video_url, p => {
    p.loop = true;
    p.muted = false;
  });

  useEffect(() => {
    if (active && !paused) player.play();
    else player.pause();
  }, [active, paused, player]);

  return (
    <View style={styles.page}>
      <Pressable style={StyleSheet.absoluteFill} onPress={() => setPaused(v => !v)}>
        <VideoView
          player={player}
          style={StyleSheet.absoluteFill}
          contentFit="cover"
          nativeControls={false}
        />
      </Pressable>

      <View style={styles.top}>
        <Text style={styles.logo}>grills<Text style={styles.logoPink}>tok.</Text></Text>
        <Text style={styles.feedLabel}>Para ti</Text>
        <Text style={styles.feedLabel}>Siguiendo</Text>
      </View>

      <View style={styles.gradientBottom} />

      <View style={styles.caption}>
        <Pressable onPress={onFollow}>
          <Text style={styles.username}>
            @{item.author.username}
            {item.author.verified ? <Text style={styles.verified}> ✓</Text> : null}
          </Text>
        </Pressable>
        <Text style={styles.description}>{item.description}</Text>
        {item.hashtags?.length > 0 && (
          <Text style={styles.hashtags}>
            {item.hashtags.map(h => h.startsWith('#') ? h : `#${h}`).join(' ')}
          </Text>
        )}
      </View>

      <View style={styles.actions}>
        <Pressable onPress={onLike} style={styles.action}>
          <Text style={[styles.icon, item.liked && styles.liked]}>♥</Text>
          <Text style={styles.count}>{item.likes_count}</Text>
        </Pressable>
        <Pressable onPress={onComment} style={styles.action}>
          <Text style={styles.icon}>●</Text>
          <Text style={styles.count}>{item.comments_count}</Text>
        </Pressable>
        <Pressable onPress={onSave} style={styles.action}>
          <Text style={[styles.icon, item.saved && styles.saved]}>★</Text>
          <Text style={styles.count}>Guardar</Text>
        </Pressable>
        <Pressable style={styles.action}>
          <Text style={styles.icon}>↗</Text>
          <Text style={styles.count}>Compartir</Text>
        </Pressable>
      </View>

      {paused && <View style={styles.pause}><Text style={styles.pauseText}>▶</Text></View>}
    </View>
  );
}

const styles = StyleSheet.create({
  page: { height: SCREEN_H, backgroundColor: '#000', position: 'relative' },
  top: {
    position: 'absolute', top: 45, left: 0, right: 0, zIndex: 5,
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 24
  },
  logo: { position: 'absolute', left: 18, color: '#fff', fontSize: 22, fontWeight: '900' },
  logoPink: { color: '#ff4fa3' },
  feedLabel: { color: '#fff', fontSize: 15, fontWeight: '700', opacity: .9 },
  gradientBottom: {
    position: 'absolute', left: 0, right: 0, bottom: 0, height: 300,
    backgroundColor: 'rgba(0,0,0,.42)'
  },
  caption: { position: 'absolute', left: 18, right: 90, bottom: 82, zIndex: 4 },
  username: { color: '#fff', fontSize: 17, fontWeight: '900', marginBottom: 8 },
  verified: { color: '#ff4fa3' },
  description: { color: '#fff', fontSize: 15, lineHeight: 21 },
  hashtags: { color: '#fff', fontWeight: '700', marginTop: 6 },
  actions: {
    position: 'absolute', right: 12, bottom: 82, zIndex: 6,
    alignItems: 'center', gap: 18
  },
  action: { alignItems: 'center', minWidth: 54 },
  icon: { color: '#fff', fontSize: 31, textShadowColor: '#000', textShadowRadius: 5 },
  liked: { color: '#ff2f91' },
  saved: { color: '#ffd85c' },
  count: { color: '#fff', fontSize: 11, fontWeight: '800', marginTop: 2 },
  pause: {
    position: 'absolute', top: '45%', left: '45%', width: 62, height: 62,
    borderRadius: 31, backgroundColor: 'rgba(0,0,0,.5)', alignItems: 'center', justifyContent: 'center'
  },
  pauseText: { color: '#fff', fontSize: 25 }
});