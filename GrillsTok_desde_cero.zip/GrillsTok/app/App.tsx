import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  Alert, FlatList, KeyboardAvoidingView, Modal, Platform, Pressable,
  SafeAreaView, StyleSheet, Text, TextInput, View, Dimensions
} from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import { File } from 'expo-file-system';
import { supabase } from '../lib/supabase';
import VideoCard, { FeedVideo } from '../components/VideoCard';

const { height } = Dimensions.get('window');

type Profile = {
  id: string;
  username: string;
  avatar_url: string | null;
  bio: string;
  verified: boolean;
};

export default function App() {
  const [session, setSession] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState<'home'|'explore'|'publish'|'activity'|'profile'>('home');

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      setSession(data.session);
      setLoading(false);
    });
    const { data: listener } = supabase.auth.onAuthStateChange((_event, next) => {
      setSession(next);
      setLoading(false);
    });
    return () => listener.subscription.unsubscribe();
  }, []);

  if (loading) return <View style={styles.center}><Text style={styles.logoBig}>grills<Text style={styles.pink}>tok.</Text></Text><Text style={styles.muted}>Cargando...</Text></View>;
  if (!session) return <AuthScreen />;

  return (
    <SafeAreaView style={styles.root}>
      {tab === 'home' && <Home userId={session.user.id} />}
      {tab === 'explore' && <Explore />}
      {tab === 'publish' && <Publish userId={session.user.id} onDone={() => setTab('home')} />}
      {tab === 'activity' && <Activity />}
      {tab === 'profile' && <ProfileScreen userId={session.user.id} />}

      <View style={styles.nav}>
        <NavButton label="Inicio" icon="⌂" active={tab==='home'} onPress={()=>setTab('home')} />
        <NavButton label="Explorar" icon="⌕" active={tab==='explore'} onPress={()=>setTab('explore')} />
        <Pressable style={styles.plus} onPress={()=>setTab('publish')}><Text style={styles.plusText}>+</Text></Pressable>
        <NavButton label="Actividad" icon="♡" active={tab==='activity'} onPress={()=>setTab('activity')} />
        <NavButton label="Perfil" icon="○" active={tab==='profile'} onPress={()=>setTab('profile')} />
      </View>
    </SafeAreaView>
  );
}

function AuthScreen() {
  const [mode, setMode] = useState<'login'|'signup'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [username, setUsername] = useState('');
  const [busy, setBusy] = useState(false);

  const submit = async () => {
    setBusy(true);
    try {
      if (mode === 'login') {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
      } else {
        if (!username.trim()) throw new Error('Escribe un nombre de usuario.');
        const { data, error } = await supabase.auth.signUp({ email, password });
        if (error) throw error;
        if (data.user) {
          await supabase.from('profiles').upsert({
            id: data.user.id, username: username.trim().toLowerCase(), bio: '', verified: false
          });
        }
        Alert.alert('Cuenta creada', 'Si tienes confirmación por correo activada, revisa tu correo.');
      }
    } catch (e: any) {
      Alert.alert('No se pudo continuar', e.message);
    } finally { setBusy(false); }
  };

  return (
    <KeyboardAvoidingView style={styles.auth} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <Text style={styles.logoBig}>grills<Text style={styles.pink}>tok.</Text></Text>
      <Text style={styles.tagline}>TU ESPACIO. TU VOZ.</Text>
      {mode === 'signup' && <TextInput placeholder="Nombre de usuario" placeholderTextColor="#8d7d89" style={styles.input} value={username} onChangeText={setUsername} autoCapitalize="none" />}
      <TextInput placeholder="Correo" placeholderTextColor="#8d7d89" style={styles.input} value={email} onChangeText={setEmail} keyboardType="email-address" autoCapitalize="none" />
      <TextInput placeholder="Contraseña" placeholderTextColor="#8d7d89" style={styles.input} value={password} onChangeText={setPassword} secureTextEntry />
      <Pressable style={styles.primary} onPress={submit} disabled={busy}>
        <Text style={styles.primaryText}>{busy ? 'Cargando...' : mode === 'login' ? 'Entrar' : 'Crear cuenta'}</Text>
      </Pressable>
      <Pressable onPress={()=>setMode(mode==='login'?'signup':'login')}>
        <Text style={styles.switch}>{mode==='login' ? '¿No tienes cuenta? Crear cuenta' : 'Ya tengo cuenta. Entrar'}</Text>
      </Pressable>
    </KeyboardAvoidingView>
  );
}

function Home({ userId }: { userId: string }) {
  const [videos, setVideos] = useState<FeedVideo[]>([]);
  const [active, setActive] = useState(0);
  const [commentsFor, setCommentsFor] = useState<FeedVideo | null>(null);

  const load = async () => {
    const { data, error } = await supabase
      .from('videos')
      .select('id,video_url,description,hashtags,likes_count,comments_count,profiles!videos_user_id_fkey(id,username,avatar_url,verified)')
      .order('created_at', { ascending: false })
      .limit(50);

    if (error) { console.log(error); return; }
    const mapped = (data ?? []).map((v: any) => ({
      ...v, author: Array.isArray(v.profiles) ? v.profiles[0] : v.profiles
    })).filter((v: any) => v.author);
    setVideos(mapped);
  };

  useEffect(() => { load(); }, []);

  const like = async (video: FeedVideo) => {
    const { data: existing } = await supabase.from('likes').select('id').eq('video_id', video.id).eq('user_id', userId).maybeSingle();
    if (existing) {
      await supabase.from('likes').delete().eq('id', existing.id);
    } else {
      await supabase.from('likes').insert({ video_id: video.id, user_id: userId });
    }
    load();
  };

  const save = async (video: FeedVideo) => {
    const { data: existing } = await supabase.from('saved_videos').select('id').eq('video_id', video.id).eq('user_id', userId).maybeSingle();
    if (existing) await supabase.from('saved_videos').delete().eq('id', existing.id);
    else await supabase.from('saved_videos').insert({ video_id: video.id, user_id: userId });
    load();
  };

  const follow = async (video: FeedVideo) => {
    if (video.author.id === userId) return;
    const { data: existing } = await supabase.from('follows').select('id').eq('follower_id', userId).eq('following_id', video.author.id).maybeSingle();
    if (existing) await supabase.from('follows').delete().eq('id', existing.id);
    else await supabase.from('follows').insert({ follower_id: userId, following_id: video.author.id });
  };

  if (!videos.length) return <View style={styles.center}><Text style={styles.empty}>Todavía no hay videos.</Text><Text style={styles.muted}>Pulsa + para publicar el primero.</Text></View>;

  return (
    <>
      <FlatList
        data={videos}
        keyExtractor={x=>x.id}
        renderItem={({item,index}) => (
          <VideoCard
            item={item}
            active={index===active}
            onLike={()=>like(item)}
            onComment={()=>setCommentsFor(item)}
            onSave={()=>save(item)}
            onFollow={()=>follow(item)}
          />
        )}
        pagingEnabled
        showsVerticalScrollIndicator={false}
        snapToInterval={height}
        decelerationRate="fast"
        onMomentumScrollEnd={e=>setActive(Math.round(e.nativeEvent.contentOffset.y / height))}
        initialNumToRender={2}
        windowSize={3}
      />
      <CommentsModal video={commentsFor} onClose={()=>setCommentsFor(null)} />
    </>
  );
}

function Explore() {
  const [q, setQ] = useState('');
  const [results, setResults] = useState<any[]>([]);
  const search = async () => {
    if (!q.trim()) return;
    const { data } = await supabase.from('profiles').select('id,username,bio,verified').ilike('username', `%${q.trim()}%`).limit(20);
    setResults(data ?? []);
  };
  return <View style={styles.screen}>
    <Text style={styles.title}>Explorar</Text>
    <View style={styles.search}><TextInput value={q} onChangeText={setQ} onSubmitEditing={search} placeholder="Buscar personas..." placeholderTextColor="#877781" style={{color:'#fff',flex:1}}/><Text style={styles.searchIcon}>⌕</Text></View>
    {results.map(p=><View key={p.id} style={styles.userRow}><View style={styles.avatar}><Text style={styles.avatarText}>{p.username?.[0]?.toUpperCase()}</Text></View><View><Text style={styles.username}>{p.username}{p.verified?' ✓':''}</Text><Text style={styles.muted}>{p.bio || 'Usuario de GrillsTok'}</Text></View></View>)}
  </View>;
}

function Publish({ userId, onDone }: { userId: string, onDone: ()=>void }) {
  const [uri, setUri] = useState<string | null>(null);
  const [caption, setCaption] = useState('');
  const [busy, setBusy] = useState(false);

  const pick = async () => {
    const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!permission.granted) return Alert.alert('Permiso necesario', 'Permite acceso a tus videos.');
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ['videos'],
      allowsMultipleSelection: false,
      videoMaxDuration: 600,
      quality: 1
    });
    if (!result.canceled) setUri(result.assets[0].uri);
  };

  const publish = async () => {
    if (!uri) return Alert.alert('Selecciona un video');
    setBusy(true);
    try {
      const file = new File(uri);
      const bytes = await file.arrayBuffer();
      const ext = (file.extension || '.mp4').replace('.', '');
      const path = `${userId}/${Date.now()}.${ext || 'mp4'}`;
      const { error: uploadError } = await supabase.storage.from('videos').upload(path, bytes, {
        contentType: 'video/mp4',
        upsert: false
      });
      if (uploadError) throw uploadError;
      const { data: publicData } = supabase.storage.from('videos').getPublicUrl(path);
      const hashtags = caption.match(/#[\p{L}\p{N}_]+/gu) ?? [];
      const clean = caption.replace(/#[\p{L}\p{N}_]+/gu, '').trim();
      const { error } = await supabase.from('videos').insert({
        user_id: userId,
        video_url: publicData.publicUrl,
        description: clean,
        hashtags
      });
      if (error) throw error;
      Alert.alert('Publicado', 'Tu video ya está en GrillsTok.');
      setUri(null); setCaption(''); onDone();
    } catch (e:any) { Alert.alert('Error al publicar', e.message); }
    finally { setBusy(false); }
  };

  return <View style={styles.screen}>
    <Text style={styles.title}>Publicar video</Text>
    <Pressable style={styles.pick} onPress={pick}>
      <Text style={styles.pickIcon}>＋</Text>
      <Text style={styles.pickText}>{uri ? 'Video seleccionado' : 'Seleccionar video'}</Text>
      <Text style={styles.muted}>Solo videos • máximo 10 minutos</Text>
    </Pressable>
    <TextInput value={caption} onChangeText={setCaption} placeholder="Describe tu video... #hashtag" placeholderTextColor="#877781" style={[styles.input, {minHeight:100, textAlignVertical:'top'}]} multiline />
    <Pressable style={styles.primary} onPress={publish} disabled={busy}><Text style={styles.primaryText}>{busy ? 'Publicando...' : 'Publicar'}</Text></Pressable>
  </View>;
}

function Activity() {
  return <View style={styles.center}><Text style={styles.title}>Actividad</Text><Text style={styles.muted}>Aquí aparecerán tus nuevos seguidores, me gusta y comentarios.</Text></View>;
}

function ProfileScreen({ userId }: { userId: string }) {
  const [profile, setProfile] = useState<Profile | null>(null);
  const [count, setCount] = useState(0);
  useEffect(() => {
    (async () => {
      const { data } = await supabase.from('profiles').select('*').eq('id', userId).single();
      setProfile(data);
      const { count } = await supabase.from('videos').select('*', { count:'exact', head:true }).eq('user_id', userId);
      setCount(count ?? 0);
    })();
  }, [userId]);
  return <View style={styles.screen}>
    <View style={styles.profileHead}>
      <View style={styles.bigAvatar}><Text style={styles.bigAvatarText}>{profile?.username?.[0]?.toUpperCase() || '?'}</Text></View>
      <Text style={styles.profileName}>@{profile?.username || 'usuario'} {profile?.verified ? <Text style={styles.pink}>✓</Text> : null}</Text>
      <Text style={styles.muted}>{profile?.bio || 'Sin biografía todavía.'}</Text>
      <View style={styles.stats}><Stat n={count} label="Videos" /><Stat n="0" label="Seguidores" /><Stat n="0" label="Siguiendo" /></View>
    </View>
    <Pressable style={styles.secondary} onPress={()=>supabase.auth.signOut()}><Text style={styles.secondaryText}>Cerrar sesión</Text></Pressable>
  </View>;
}

function Stat({n,label}:{n:any,label:string}) { return <View style={{alignItems:'center',minWidth:90}}><Text style={styles.statN}>{n}</Text><Text style={styles.muted}>{label}</Text></View>; }

function CommentsModal({video,onClose}:{video:FeedVideo|null,onClose:()=>void}) {
  const [text,setText]=useState('');
  const [comments,setComments]=useState<any[]>([]);
  useEffect(()=>{ if(!video)return; supabase.from('comments').select('id,body,created_at,profiles(username,verified)').eq('video_id',video.id).order('created_at',{ascending:false}).limit(50).then(({data})=>setComments(data??[])); },[video]);
  const send=async()=>{ if(!video||!text.trim())return; const {data:{user}}=await supabase.auth.getUser(); if(!user)return; await supabase.from('comments').insert({video_id:video.id,user_id:user.id,body:text.trim()}); setText(''); const {data}=await supabase.from('comments').select('id,body,created_at,profiles(username,verified)').eq('video_id',video.id).order('created_at',{ascending:false}).limit(50); setComments(data??[]); };
  return <Modal visible={!!video} animationType="slide" transparent onRequestClose={onClose}><View style={styles.modalWrap}><View style={styles.modal}><View style={styles.modalHeader}><Text style={styles.title}>Comentarios</Text><Pressable onPress={onClose}><Text style={styles.close}>×</Text></Pressable></View><FlatList data={comments} keyExtractor={x=>x.id} ListEmptyComponent={<Text style={styles.muted}>Sé la primera persona en comentar.</Text>} renderItem={({item})=><View style={styles.comment}><Text style={styles.commentUser}>@{item.profiles?.username}{item.profiles?.verified?' ✓':''}</Text><Text style={styles.commentText}>{item.body}</Text></View>} /><View style={styles.commentInput}><TextInput value={text} onChangeText={setText} placeholder="Añade un comentario..." placeholderTextColor="#877781" style={{flex:1,color:'#fff'}}/><Pressable onPress={send}><Text style={styles.pink}>Enviar</Text></Pressable></View></View></View></Modal>;
}

function NavButton({label,icon,active,onPress}:{label:string,icon:string,active:boolean,onPress:()=>void}) {
  return <Pressable style={styles.navButton} onPress={onPress}><Text style={[styles.navIcon,active&&styles.navActive]}>{icon}</Text><Text style={[styles.navLabel,active&&styles.navActive]}>{label}</Text></Pressable>;
}

const styles=StyleSheet.create({
  root:{flex:1,backgroundColor:'#08070b'}, center:{flex:1,backgroundColor:'#08070b',alignItems:'center',justifyContent:'center',padding:30},
  auth:{flex:1,backgroundColor:'#08070b',justifyContent:'center',padding:28}, logoBig:{fontSize:42,fontWeight:'900',color:'#fff'},pink:{color:'#ff4fa3'},tagline:{color:'#c4aebd',letterSpacing:3,fontWeight:'700',marginBottom:40,marginTop:5},
  input:{backgroundColor:'#171018',borderWidth:1,borderColor:'#342633',borderRadius:14,padding:15,color:'#fff',marginBottom:12,fontSize:15},
  primary:{backgroundColor:'#ff4fa3',padding:16,borderRadius:14,alignItems:'center',marginTop:4},primaryText:{color:'#160b12',fontWeight:'900',fontSize:16},
  switch:{color:'#ff9bc6',textAlign:'center',marginTop:20,fontWeight:'700'}, muted:{color:'#9f8f9a',lineHeight:20}, empty:{color:'#fff',fontSize:21,fontWeight:'900',marginBottom:8},
  nav:{position:'absolute',bottom:0,left:0,right:0,height:68,backgroundColor:'rgba(11,7,12,.96)',borderTopWidth:1,borderTopColor:'#30232f',flexDirection:'row',alignItems:'center',justifyContent:'space-around',zIndex:20},
  navButton:{width:70,alignItems:'center'},navIcon:{color:'#a998a5',fontSize:25},navLabel:{color:'#a998a5',fontSize:10,marginTop:2},navActive:{color:'#ff8abd'},
  plus:{width:48,height:34,borderRadius:10,backgroundColor:'#fff',alignItems:'center',justifyContent:'center'},plusText:{fontSize:28,lineHeight:30,color:'#111'},
  screen:{flex:1,backgroundColor:'#08070b',padding:20,paddingTop:55},title:{color:'#fff',fontSize:28,fontWeight:'900',marginBottom:20},
  search:{flexDirection:'row',alignItems:'center',backgroundColor:'#171018',borderRadius:14,paddingHorizontal:15,marginBottom:20},searchIcon:{color:'#ff8abd',fontSize:27},
  userRow:{flexDirection:'row',alignItems:'center',paddingVertical:14,borderBottomWidth:1,borderBottomColor:'#241b24',gap:13},avatar:{width:48,height:48,borderRadius:24,backgroundColor:'#ff4fa3',alignItems:'center',justifyContent:'center'},avatarText:{fontWeight:'900',fontSize:20,color:'#1b0b14'},username:{color:'#fff',fontSize:16,fontWeight:'900'},pick:{borderWidth:1,borderStyle:'dashed',borderColor:'#70405d',borderRadius:18,minHeight:210,alignItems:'center',justifyContent:'center',marginBottom:18},pickIcon:{color:'#ff7fb5',fontSize:55},pickText:{color:'#fff',fontSize:19,fontWeight:'900',marginTop:8},profileHead:{alignItems:'center',paddingTop:15},bigAvatar:{width:96,height:96,borderRadius:48,backgroundColor:'#ff4fa3',alignItems:'center',justifyContent:'center',marginBottom:12},bigAvatarText:{fontSize:38,fontWeight:'900',color:'#1a0912'},profileName:{color:'#fff',fontSize:22,fontWeight:'900',marginBottom:5},stats:{flexDirection:'row',justifyContent:'space-around,width:100%',marginTop:25,marginBottom:30},statN:{color:'#fff',fontSize:19,fontWeight:'900'},secondary:{borderWidth:1,borderColor:'#5b3a4e',borderRadius:14,padding:14,alignItems:'center'},secondaryText:{color:'#fff',fontWeight:'800'},
  modalWrap:{flex:1,backgroundColor:'rgba(0,0,0,.55)',justifyContent:'flex-end'},modal:{height:'72%',backgroundColor:'#120c13',borderTopLeftRadius:24,borderTopRightRadius:24,padding:18},modalHeader:{flexDirection:'row',justifyContent:'space-between',alignItems:'center'},close:{color:'#fff',fontSize:32},comment:{paddingVertical:12,borderBottomWidth:1,borderBottomColor:'#251b25'},commentUser:{color:'#fff',fontWeight:'900'},commentText:{color:'#ddd',marginTop:3},commentInput:{flexDirection:'row',alignItems:'center',borderTopWidth:1,borderTopColor:'#30232f',paddingTop:12}
});