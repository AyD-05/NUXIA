-- Ejecuta este SQL en Supabase > SQL Editor.
-- Crea las tablas necesarias para una red social de videos.

create extension if not exists "pgcrypto";

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique not null,
  avatar_url text,
  bio text default '',
  verified boolean default false,
  created_at timestamptz default now()
);

create table if not exists public.videos (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  video_url text not null,
  description text default '',
  hashtags text[] default '{}',
  likes_count integer default 0,
  comments_count integer default 0,
  created_at timestamptz default now()
);

create table if not exists public.likes (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  video_id uuid not null references public.videos(id) on delete cascade,
  created_at timestamptz default now(),
  unique(user_id, video_id)
);

create table if not exists public.saved_videos (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  video_id uuid not null references public.videos(id) on delete cascade,
  created_at timestamptz default now(),
  unique(user_id, video_id)
);

create table if not exists public.follows (
  id uuid primary key default gen_random_uuid(),
  follower_id uuid not null references public.profiles(id) on delete cascade,
  following_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz default now(),
  unique(follower_id, following_id),
  check (follower_id <> following_id)
);

create table if not exists public.comments (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  video_id uuid not null references public.videos(id) on delete cascade,
  body text not null check (char_length(body) between 1 and 500),
  created_at timestamptz default now()
);

-- Contadores automáticos
create or replace function public.refresh_video_counts()
returns trigger language plpgsql security definer as $$
begin
  if TG_TABLE_NAME = 'likes' then
    update public.videos set likes_count = (select count(*) from public.likes where video_id = coalesce(new.video_id, old.video_id))
    where id = coalesce(new.video_id, old.video_id);
  elsif TG_TABLE_NAME = 'comments' then
    update public.videos set comments_count = (select count(*) from public.comments where video_id = coalesce(new.video_id, old.video_id))
    where id = coalesce(new.video_id, old.video_id);
  end if;
  return coalesce(new, old);
end;
$$;

drop trigger if exists likes_count_trigger on public.likes;
create trigger likes_count_trigger after insert or delete on public.likes
for each row execute function public.refresh_video_counts();

drop trigger if exists comments_count_trigger on public.comments;
create trigger comments_count_trigger after insert or delete on public.comments
for each row execute function public.refresh_video_counts();

-- RLS
alter table public.profiles enable row level security;
alter table public.videos enable row level security;
alter table public.likes enable row level security;
alter table public.saved_videos enable row level security;
alter table public.follows enable row level security;
alter table public.comments enable row level security;

create policy "profiles readable" on public.profiles for select using (true);
create policy "own profile insert" on public.profiles for insert with check (auth.uid() = id);
create policy "own profile update" on public.profiles for update using (auth.uid() = id);

create policy "videos readable" on public.videos for select using (true);
create policy "own videos insert" on public.videos for insert with check (auth.uid() = user_id);
create policy "own videos update" on public.videos for update using (auth.uid() = user_id);
create policy "own videos delete" on public.videos for delete using (auth.uid() = user_id);

create policy "likes readable" on public.likes for select using (true);
create policy "own likes insert" on public.likes for insert with check (auth.uid() = user_id);
create policy "own likes delete" on public.likes for delete using (auth.uid() = user_id);

create policy "saved readable" on public.saved_videos for select using (true);
create policy "own saved insert" on public.saved_videos for insert with check (auth.uid() = user_id);
create policy "own saved delete" on public.saved_videos for delete using (auth.uid() = user_id);

create policy "follows readable" on public.follows for select using (true);
create policy "own follow insert" on public.follows for insert with check (auth.uid() = follower_id);
create policy "own follow delete" on public.follows for delete using (auth.uid() = follower_id);

create policy "comments readable" on public.comments for select using (true);
create policy "own comment insert" on public.comments for insert with check (auth.uid() = user_id);
create policy "own comment delete" on public.comments for delete using (auth.uid() = user_id);

-- Storage: crea un bucket público llamado videos.
insert into storage.buckets (id, name, public)
values ('videos', 'videos', true)
on conflict (id) do update set public = true;

create policy "video files public read"
on storage.objects for select
using (bucket_id = 'videos');

create policy "authenticated upload videos"
on storage.objects for insert to authenticated
with check (bucket_id = 'videos' and (storage.foldername(name))[1] = auth.uid()::text);

create policy "users delete own videos"
on storage.objects for delete to authenticated
using (bucket_id = 'videos' and (storage.foldername(name))[1] = auth.uid()::text);

-- IMPORTANTE:
-- verified NO se debe poder modificar desde la app.
-- Para verificar a alguien, cambia verified=true desde el panel de Supabase
-- después de revisar la cuenta.
