# GrillsTok — red social de videos

Esta versión empieza desde cero y está pensada como una red social de videos verticales:
- feed de pantalla completa;
- reproducción automática y bucle;
- deslizar arriba/abajo;
- me gusta;
- comentarios;
- guardar;
- seguir usuarios;
- compartir (base para integrar el sistema nativo);
- registro e inicio de sesión;
- publicación de videos desde el teléfono;
- perfiles;
- búsqueda de usuarios;
- cuentas verificadas mediante `verified=true` administrado desde Supabase;
- sin anuncios promocionales ni tarjetas de imágenes en el feed.

## 1. Crear el proyecto

Puedes usar un proyecto Expo nuevo y copiar estos archivos.

```bash
npm install
```

## 2. Crear Supabase

Crea un proyecto en Supabase y abre el SQL Editor.

Copia TODO el contenido de:

`supabase/schema.sql`

y ejecútalo.

Supabase proporciona Auth, base de datos y Storage para este tipo de aplicación. La app usa esas piezas para cuentas, videos y datos sociales.

## 3. Configurar las claves

Copia `.env.example` a `.env` y pon:

```env
EXPO_PUBLIC_SUPABASE_URL=...
EXPO_PUBLIC_SUPABASE_PUBLISHABLE_KEY=...
```

## 4. Ejecutar

```bash
npx expo start
```

Luego abre la app con Expo Go.

## 5. Verificación

La insignia azul/rosa de verificación se controla en la base de datos.

Por seguridad, un usuario normal no puede ponerse `verified=true` desde la aplicación. El administrador puede aprobar cuentas desde Supabase.

## 6. Qué falta para una versión de producción

La base está preparada para crecer. Antes de publicar públicamente conviene añadir:
- moderación automática/manual de videos;
- reportar video/usuario;
- bloqueo;
- sistema de notificaciones push;
- procesamiento y compresión de video en servidor;
- generación de miniaturas;
- paginación infinita;
- recomendaciones personalizadas;
- límites anti-spam;
- recuperación de contraseña;
- panel de administración;
- métricas;
- términos, privacidad y controles de edad;
- sistema de compartir profundo y enlaces de video.

No copia logos, código ni recursos propietarios de TikTok; reproduce la experiencia general de una red social de videos verticales.
